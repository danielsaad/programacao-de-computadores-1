#include "escrita.h"
#include <stdio.h>

void imprime_string(char str[]){
    printf("%s\n",str);
}