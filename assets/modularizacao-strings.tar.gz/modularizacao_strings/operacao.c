#include "operacao.h"

size_t tamanho_string(char str[]){
    size_t tam;
    for(tam=0;str[tam]!='\0';tam++);
    return tam;
}

bool palindromo(char str[]){
    bool res = true;
    size_t tam = tamanho_string(str);
    for(size_t i=0,j=tam-1;i<j;i++,j--){
        if(str[i] != str[j]){
            res = false;
        }
    }
    return res;
}

void converte_maiusculo(char str[]){
    size_t tam = tamanho_string(str);
    for(size_t i=0;i<tam;i++){
        if(str[i]>='a' && str[i]<='z'){
            str[i] -= 32;
        }
    }
}
void converte_minusculo(char str[]){
    size_t tam = tamanho_string(str);
    for(size_t i=0;i<tam;i++){
        if(str[i]>='A' && str[i]<='Z'){
            str[i] += 32;
        }
    }
}

int compara_strings(char str1[],char str2[]){
   size_t i=0;
   while(str1[i] == str2[i]){
        i++;
    } 
   return str1[i]-str2[i];
}
void concatenacao_strings(char str1[],char str2[]){
    size_t tam1,tam2;
    tam1 = tamanho_string(str1);
    tam2 = tamanho_string(str2);
    for(size_t i=0;i<tam2;i++){
        str1[tam1+i] = str2[i];
    }
    str1[tam1+tam2] = '\0';
}