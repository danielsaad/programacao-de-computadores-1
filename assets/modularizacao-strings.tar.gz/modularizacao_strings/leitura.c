#include "leitura.h"
#include "operacao.h"
#include <stdio.h>

void le_linha(char str[],size_t n){
    fgets(str,n,stdin);
    size_t tam = tamanho_string(str);
    if(str[tam-1]=='\n')
        str[tam-1]='\0';
}