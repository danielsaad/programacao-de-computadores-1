#ifndef OPERACAO_H
#define OPERACAO_H
#include <stdlib.h>
#include <stdbool.h>

size_t tamanho_string(char str[]);
bool palindromo(char str[]);
void converte_maiusculo(char str[]);
void converte_minusculo(char str[]);
int compara_strings(char str1[],char str2[]);
void concatenacao_strings(char str1[],char str2[]);

#endif