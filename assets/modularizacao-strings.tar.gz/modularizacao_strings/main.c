#include <stdio.h>
#include "leitura.h"
#include "escrita.h"
#include "operacao.h"

#define MAX 100

int main(void){
    char str1[MAX];
    char str2[MAX];
    le_linha(str1,100);
    le_linha(str2,100);
    int cmp = compara_strings(str1,str2);
    if(cmp < 0){
        imprime_string(str1);
        printf("menor do que\n");
        imprime_string(str2);
    }
    else if(cmp > 0){
        imprime_string(str1);
        printf("maior do que\n");
        imprime_string(str2);
    }
    else{
        imprime_string(str1);
        printf("é igual a\n");
        imprime_string(str2);
    }
    return 0;
}