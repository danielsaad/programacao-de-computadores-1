#ifndef LEITURA_H
#define LEITURA_H
#include <stdlib.h>

void le_linha(char str[],size_t n);

#endif