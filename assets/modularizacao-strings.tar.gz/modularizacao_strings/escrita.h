#ifndef ESCRITA_H
#define ESCRITA_H

void imprime_string(char str[]);

#endif