#include <stdio.h>

int main(void){
    int n,i,j;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        int espacos = n - i;
        int asteriscos = 2*i-1;
        for(j=1;j<=espacos;j++){
            printf(" ");
        }
        for(j=1;j<=asteriscos;j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
