#include <stdio.h>

int main(void){
    int n,a,b,c;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d %d %d",&a,&b,&c);
        int tem_solucao = 0;
        for(int x=-100;x<=100 && !tem_solucao;x++){
            for(int y=-100;y<=100 && !tem_solucao;y++){
                for(int z=-100;z<=100 && !tem_solucao;z++){
                    if(x + y + z == a &&
                        x * y * z == b &&
                        x*x + y*y + z*z == c &&
                        x!=y && y!=z && x!=z){
                            printf("%d %d %d\n",x,y,z);                      
                            tem_solucao = 1;      
                        }
                }
            }
        }
        if(!tem_solucao){
            printf("Sem solucao\n");
        }
    }
}