#include <stdio.h>

int main(void){
    int n;
    int divisor;
    int primo = 1;
    scanf("%d",&n);
    for(divisor=2;divisor<=sqrt(n);divisor++){
        if(n % divisor == 0){
            primo = 0;
            break;
        }
    }
    if(primo){
        printf("Primo!\n");
    }
    else{
        printf("Composto!\n");
    }
    return 0;
}
