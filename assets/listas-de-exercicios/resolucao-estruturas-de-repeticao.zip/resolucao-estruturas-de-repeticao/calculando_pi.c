#include <stdio.h>

int main(void){
    int nro_termos = 10000;
    double quarto_pi = 0.0;
    int n;
    for(n=0;n<nro_termos;n++){
        quarto_pi = quarto_pi +  2.0/((4*n+1)*(4*n+3));
    }
    printf("%f\n",4*quarto_pi);
    return 0;
}
