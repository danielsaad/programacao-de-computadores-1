#include <stdio.h>
#include <string.h>

int quebra_cabeca(char str[]){
	int n = strlen(str);
	int freq[128];
	int impar = 0;
	for(int i=0;i<128;i++){
		freq[i] = 0;
	}
	for(int i=0;i<n;i++){
		freq[str[i]]++;
	}
	for(int i=0;i<128;i++){
		if(freq[i] % 2 != 0){
			impar++;
		}
	}
	return impar <=1 ;
}

int main(void){
	char str[1001];
	scanf("%s",str);
	int ans = quebra_cabeca(str);
	if(ans){
		printf("Sim\n");
	}
	else{
		printf("Nao\n");
	}
	return 0;
}
