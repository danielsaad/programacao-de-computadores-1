#include <stdio.h>
#include <string.h>
int main(void){
	char str[1001];
	scanf("%s",str);
	int n = strlen(str);
	int count = 1;
	for(int i = 1 ; i <=n ; i++){
		if(str[i]==str[i-1]){
			count++;
		}
		else{
			if(count > 1){
				printf("%d",count);
			}
			printf("%c",str[i-1]);
			count = 1;
		}
	}
	printf("\n");
	return 0;
}
