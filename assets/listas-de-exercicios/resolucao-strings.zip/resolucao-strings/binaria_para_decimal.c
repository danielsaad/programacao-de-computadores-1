#include <stdio.h>
#include <string.h>

int binario_para_decimal(char str[]){
	int n = strlen(str);
	int dec = 0;
	for(int i=0;i<n;i++){
		dec *= 2;
		dec += str[i] - '0';
	}
	return dec;
}

int main(void){
	char str[31];
	scanf("%s",str);
	int decimal = binario_para_decimal(str);
	printf("%d\n",decimal);
	return 0;
}

