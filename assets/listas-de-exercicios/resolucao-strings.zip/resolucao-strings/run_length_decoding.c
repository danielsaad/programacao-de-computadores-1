#include <stdio.h>
#include <string.h>
int main(void){
	char str[1001];
	scanf("%s",str);
	int n = strlen(str);
	int i = 0;
	while(i<n){
		int count = 0;
		while(str[i]>='0' && str[i]<='9'){
			count *= 10;
			count+= str[i]-'0';
			i++;
		}
		
		for(int j=0;j<count-1;j++){
			printf("%c",str[i]);
		}
		printf("%c",str[i]);
		i++;
	}
	printf("\n");
	return 0;
}
