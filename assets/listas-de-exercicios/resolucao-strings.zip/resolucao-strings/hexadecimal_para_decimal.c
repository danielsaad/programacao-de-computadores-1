#include <stdio.h>
#include <string.h>

long long int hexa_para_decimal(char str[]){
	int n = strlen(str);
	long long int dec = 0;
	for(int i=0;i<n;i++){
		dec *= 16;
		if(str[i] >= '0' && str[i] <= '9'){
			dec += str[i] - '0';
		}
		else{
			dec += str[i] - 'a' + 10;
		}
	}
	return dec;
}

int main(void){
	char str[9];
	scanf("%s",str);
	long long int decimal = hexa_para_decimal(str);
	printf("%lld\n",decimal);
	return 0;
}

