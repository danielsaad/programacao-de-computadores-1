#include <stdio.h>
#include <string.h>

int verifica_palindromo(char str[]){
	int n = strlen(str);
	for(int i=0,j=n-1;i<j;i++,j--){
		if(str[i] != str[j]){
			return 0;
		}
	}
	return 1;
}

int main(void){
	char str[81];
	scanf("%s",str);
	int palindromo = verifica_palindromo(str);
	if(palindromo){
		printf("S\n");
	}
	else{
		printf("N\n");
	}
	return 0;
}
