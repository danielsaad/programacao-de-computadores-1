#include <stdio.h>
#include <string.h>
int main(void){
    int i,j;
    char texto[1002];
    char padrao[102];
    fgets(texto,1002,stdin);
    fgets(padrao,102,stdin);
    int tam_texto = strlen(texto)-1;
    int tam_padrao = strlen(padrao)-1;
    for(i=0;i<=tam_texto-tam_padrao;i++){
        int igual = 1;
        for(j=0;j<tam_padrao;j++){
            if(texto[i+j]!=padrao[j]){
                igual = 0;
                break;
            }
        }
        if(igual){
            printf("%d ",i);
        }
    }
    printf("\n");
    return 0;
}