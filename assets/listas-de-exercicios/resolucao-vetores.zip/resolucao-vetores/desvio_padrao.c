#include <stdio.h>
#include <math.h>

float calcula_media(float notas[], int n){
	float media = 0;
    for(int i=0;i<n;i++){
        media += notas[i];
    }
    media /= n;
    return media;
}

float calcula_variancia(float notas[],int n, float media){
	float variancia = 0;
    for(int i=0;i<n;i++){
        variancia += pow(notas[i]-media,2);
    }
    variancia /= n;
    return variancia;
}

float calcula_desvio_padrao(float variancia){
	return sqrt(variancia);
}

int main(void){
    int i,n;
    float media,variancia,desvio_padrao;
    scanf("%d",&n);
    float notas[n];
    for(i=0;i<n;i++){
        scanf("%f",&notas[i]);
    }
	media = calcula_media(notas,n);
	variancia = calcula_variancia(notas,n,media);
    desvio_padrao = calcula_desvio_padrao(variancia);
    printf("%f\n",desvio_padrao);
    return 0;
}
