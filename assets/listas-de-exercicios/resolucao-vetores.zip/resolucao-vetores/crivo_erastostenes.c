#include <stdio.h>
#include <math.h>

int primo[10000001];

void inicializa_crivo(int primo[], int n){
    for(int i=0;i<=10000000;i++){
        primo[i] = 1;
    }
}

void descarta_divisiveis(int primo[],int n,int divisor){
	for(int i=divisor*2;i<=10000000;i+=divisor){
		primo[i] = 0;         
     }
}

void computa_crivo(int primo[],int n){
    primo[0] = 0;
    primo[1] = 0;
    for(int num=2;num<=sqrt(10000000);num++){
        if(primo[num]){
			descarta_divisiveis(primo,n,num);
        }
    }
}

int main(void){
    int i,n,num;
    scanf("%d",&n);
    inicializa_crivo(primo,n);
    computa_crivo(primo,n);
    for(i=0;i<n;i++){
        scanf("%d",&num);
        primo[num]==1 ? printf("primo\n") : printf("composto\n");
    }
    return 0;
}
