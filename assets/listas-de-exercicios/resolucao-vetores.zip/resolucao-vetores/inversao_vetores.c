#include <stdio.h>
#include <math.h>
#include <float.h>

void le_vetor(int v[], int n){
	for(int i=0;i<n;i++){
		scanf("%d",&v[i]);
	}
}

void inverte(int v[], int n){
	for(int i=0,j=n-1;i<j;i++,j--){
		int aux = v[i];
		v[i] = v[j];
		v[j] = aux;
	}
}

void imprime_vetor(int v[],int n){
	for(int i=0;i<n;i++){
		printf("%d ",v[i]);
	}
	printf("\n");
}


int main(void){
    int n;
    scanf("%d",&n);
    int vetor[n];
    le_vetor(vetor,n);
	inverte(vetor,n);
	imprime_vetor(vetor,n);
    return 0;
}
