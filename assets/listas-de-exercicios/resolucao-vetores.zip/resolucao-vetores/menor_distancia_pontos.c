#include <stdio.h>
#include <math.h>
#include <float.h>

void le_vetor(float vetor[], int n){
	for(int i=0;i<n;i++){
		scanf("%f",&vetor[i]);
	}
}

float distancia(float x[], float y[], int i, int j){
	float dist = sqrt( (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) );
	return dist;
}

void resolve(float x[], float y[], int n){
	float distancia_minima = FLT_MAX;
	int indice_a,indice_b;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			float dist = distancia(x,y,i,j);
			if(dist < distancia_minima){
				distancia_minima = dist;
				indice_a = i;
				indice_b = j;
			}
		}
	}
	printf("Pontos: %d e %d\n",indice_a,indice_b);
	printf("Distancia: %f\n",distancia_minima);
}

int main(void){
    int n;
    scanf("%d",&n);
    float x[n];
    float y[n];
    le_vetor(x,n);
    le_vetor(y,n);
	resolve(x,y,n);
    return 0;
}
