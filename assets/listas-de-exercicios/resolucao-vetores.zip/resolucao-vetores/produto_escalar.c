#include <stdio.h>
#include <math.h>


void le_vetor(float vetor[], int n){
	for(int i=0;i<n;i++){
		scanf("%f",&vetor[i]);
	}
}

float calcula_produto_escalar(float vetor_a[], float vetor_b[], int n){
	float prod_esc = 0;
	for(int i=0;i<n;i++){
		prod_esc += vetor_a[i] * vetor_b[i];
	}
	return prod_esc;
}

int main(void){
    int n;
    scanf("%d",&n);
    float vetor_a[n];
    float vetor_b[n];
    le_vetor(vetor_a,n);
    le_vetor(vetor_b,n);
	float prod_esc = calcula_produto_escalar(vetor_a,vetor_b,n);
	printf("%f\n",prod_esc);
    return 0;
}
