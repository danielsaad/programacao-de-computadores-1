#include <stdio.h>
#include <math.h>

char crivo[10000001];

int main()
{
    //Monta crivo
    int i, j;
    crivo[0] = 0;
    crivo[1] = 0;
    for (i = 2; i  <= 10000000; i++)
    {
        crivo[i] = 1;
    }
    for (i = 2; i*i <= 10000000; i++)
    {
        if (crivo[i] != 0)
        {
            for (j = 2*i; j < 10000001; j = j+i)
            {
                crivo[j] = 0;
            }
        }
    }
    
    int N, num, a;
    scanf("%d", &N);
    int q[N];
    for (i = 0; i < N; i++)
    {
        scanf("%d",&q[i]);
    }
    for(i=0;i<N;i++){
        num = q[i];
        a = 1;
        while (num > 0)
        {
            if (crivo[num] == 0)
            {
                a = 0;
                break;
            }
            num = num/10;
        }
        a == 1 ? printf("S\n") : printf("N\n");
    }   
    return 0;
}
