#include <stdio.h>
typedef struct rainha{
    int i,j;
} rainha;

void resolve(rainha* v,int n,int* tem_solucao){
    if(*tem_solucao) return;
    if(n==8){
        for(int k=0;k<8;k++){
            printf("%d %d\n",v[k].i,v[k].j);
        }
        *tem_solucao = 1;
    }
    else{
        v[n].j = n;
        for(int k=0;k<8;k++){
            int possivel = 1;
            v[n].i = k;
            for(int l=0;l<n;l++){
                int dist = n-l;
                if( (v[l].i == v[n].i) ||
                    (v[l].i +dist == v[n].i && v[l].j + dist == v[n].j) ||
                    (v[l].i -dist == v[n].i && v[l].j+dist == v[n].j)){
                    possivel = 0;
                }
            }
            if(possivel){
                resolve(v,n+1,tem_solucao); 
            }
        }
    }
}

int main(void){
    rainha v[8];
    int tem_solucao = 0;
    resolve(v,0,&tem_solucao);
    return 0;
}