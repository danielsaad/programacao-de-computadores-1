#include <stdbool.h>
#include <stdio.h>

typedef struct puzzle {
  bool tem_solucao;
  int tabuleiro[5][5];
  int i0, j0;
} puzzle;

void le_entrada(puzzle* p){
    scanf("%d %d",&p->i0,&p->j0);
}

void inicializa(puzzle* p){
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            p->tabuleiro[i][j] = 0;
        }
    }
    p->tem_solucao = false; 
}

void resolve(puzzle* p,int i,int j,int mov){
    p->tabuleiro[i][j] = mov;
    if(mov == 25 && !p->tem_solucao){
        for(int k=4;k>=0;k--){
            for(int l=0;l<5;l++){
                printf("%3d",p->tabuleiro[k][l]);
            }
            printf("\n");
        }
        p->tem_solucao = true;
    }
    else{
        int mov_i[] = {1,1,2,2,-1,-1,-2,-2};
        int mov_j[] = {2,-2,1,-1,2,-2,1,-1};
        for(int m=0;m<8;m++){
            int prox_i = i + mov_i[m];
            int prox_j = j + mov_j[m];
            if(prox_i <0 || prox_i >=5 || prox_j <0 || prox_j>=5 || 
                p->tabuleiro[prox_i][prox_j]!=0) continue;
                resolve(p,prox_i,prox_j,mov+1);
        }
    }
    p->tabuleiro[i][j] = 0;
}

int main(void) { 
    puzzle p;
    le_entrada(&p);
    inicializa(&p);
    resolve(&p,p.i0,p.j0,1);
    if(p.tem_solucao==false){
        printf("-1\n");
    }
    return 0; 
}
