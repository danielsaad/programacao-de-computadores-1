#include <stdio.h>

void recursao(char* alfabeto,int i,int k,char* palavra){
	if(i==k){
		palavra[i]='\0';
		printf("%s\n",palavra);
	}
	else{
		for(int j=0;alfabeto[j]!='\0';j++){
			palavra[i] = alfabeto[j];
			recursao(alfabeto,i+1,k,palavra);
		}
	}
}

void resolve(char* alfabeto, int n,int k){
	char palavra[k+1];
	recursao(alfabeto,0,k,palavra);
}

int main(void){
	int n,k;
	char alfabeto[100];
	scanf("%d %d",&n,&k);
	scanf("%s",alfabeto);	
	resolve(alfabeto,n,k);
	return 0;
}
