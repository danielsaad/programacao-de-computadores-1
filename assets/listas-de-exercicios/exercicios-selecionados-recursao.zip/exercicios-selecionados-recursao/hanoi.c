#include <stdio.h>
void hanoi(int n, char origem, char destino, char auxiliar,int* movimento){
	if (n==1){
		(*movimento)++;
		//printf("Movimento %d -> Movendo o disco %d da estaca %c para a estaca %c\n",*movimento,n,origem,destino);
	}
	else{
		hanoi(n-1,origem,auxiliar,destino,movimento);
		(*movimento)++;
		//printf("Movimento %d -> Movendo o disco %d da estaca %c para  estaca %c\n",*movimento,n,origem,destino);
		hanoi(n-1,auxiliar,destino,origem,movimento);
	}
}
int main(void){
	int movimento = 0;
	hanoi(100,'A','B','C',&movimento);
	return 0;
}
