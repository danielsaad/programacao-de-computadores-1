#include <stdio.h>
#define MAX 88
void computa_fib(long long int *f) {
  f[0] = 1;
  f[1] = 1;
  for (int i = 2; i < MAX; i++) {
    f[i] = f[i - 1] + f[i - 2];
  }
}
void recursao(long long int* f,long long int i, int idx){
    // printf("%lld %d %lld\n",i,idx,f[idx]);
    if(i==0){
        printf("b\n");
    }
    else if(i==1){
        printf("a\n");
    }
    else{
        if(i<f[idx-1]){
            recursao(f,i,idx-1);
        }
        else{
            recursao(f,i-f[idx-1],idx-2);
        }
    }
}
void resolve(long long int* f,long long int i){
    int idx = 0;
    while(f[idx]<=i){
        idx++;
    }
    // printf("Resolvendo para %lld\n",i);
    recursao(f,i,idx);
}

int main(void) {
  long long int f[MAX];
  computa_fib(f);
  int n;
  scanf("%d",&n);
  while(n--){
    long long int  i;
    scanf("%lld",&i);
    resolve(f,i);
  }
  return 0;
}